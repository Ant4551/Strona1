<?php

/**
 * Add common scripts and styles for np controls
 */
function add_common_scripts() {
    global $post;
    $post_id = isset($post->ID) ? $post->ID : 0;
    if (np_data_provider($post_id)->isNp()) {
        wp_register_script('common-np-scripts', APP_PLUGIN_URL . 'includes/common/js/np-scripts.js', array('jquery'), time(), false);
        wp_enqueue_script('common-np-scripts');
    }
}
add_action('wp_enqueue_scripts', 'add_common_scripts', 1003);

function filter_posts_by_category($query) {
    if ($query->is_main_query() && !is_admin()) {
        $category_id = isset($_GET['postsCategoryId']) ? intval($_GET['postsCategoryId']) : 0;
        if ($category_id > 0) {
            $query->set('cat', $category_id);
        }
    }
}
add_action('pre_get_posts', 'filter_posts_by_category');

/**
 * Get active plugin template type for Blog sorting.
 *
 * @param WP_Query $query
 *
 * @return string
 */
function np_get_sorting_template_type($query) {
    if ($query->is_feed()) {
        return '';
    }

    $higher_priority_routes = array(
        array('products-list', 'productsList'),
        array('product-id', 'productId'),
        array('thank-you', 'thankYou'),
    );
    foreach ($higher_priority_routes as $route) {
        if ($query->get($route[0], null) !== null || isset($_GET[$route[1]])) {
            return '';
        }
    }

    $is_shop = function_exists('wc_get_product')
        && (
            $query->is_post_type_archive('product')
            || $query->is_tax('product_cat')
        );
    if ($query->is_home() || ($query->is_archive() && !$is_shop)) {
        return 'blog';
    }
    if ($query->is_search()) {
        return 'search';
    }
    return '';
}

/**
 * Get publish HTML for a template without changing the global post.
 *
 * @param int $template_id
 *
 * @return string
 */
function np_get_template_publish_html_for_sorting($template_id) {
    $meta_name = '_np_publish_html';
    $data_provider = np_data_provider($template_id);
    $language = isset($data_provider->language) ? $data_provider->language : '';
    if (!$language && isset($GLOBALS['np_current_process_lang'])) {
        $language = $GLOBALS['np_current_process_lang'];
    }
    if ($language) {
        $default_language = get_option('np_default_lang');
        $translated_meta_name = $language . '_np_publish_html';
        if ($default_language && $language !== $default_language && metadata_exists('post', $template_id, $translated_meta_name)) {
            $meta_name = $translated_meta_name;
        }
    }
    if ($data_provider->isPreview()) {
        $preview_html = get_post_meta($template_id, $meta_name . '_preview', true);
        if ($preview_html) {
            return $preview_html;
        }
    }
    return get_post_meta($template_id, $meta_name, true);
}

/**
 * Apply requested or saved Blog sorting to the main query.
 *
 * @param WP_Query $query
 */
function sorting_posts($query) {
    if (is_admin() || !$query->is_main_query()) {
        return;
    }

    $has_requested_sorting = isset($_GET['postsSorting']) && $_GET['postsSorting'] !== '';
    if ($has_requested_sorting) {
        $sorting = NpBlogPostDataReplacer::resolveBlogSorting();
    } else {
        if (get_option('np_theme_appearance') !== 'plugin-option' || !Nicepage::isNpTheme()) {
            return;
        }
        $template_type = np_get_sorting_template_type($query);
        if (!$template_type) {
            return;
        }
        $templates = get_templates($template_type);
        if (empty($templates) || empty($templates[0]->ID)) {
            return;
        }
        $template_html = np_get_template_publish_html_for_sorting($templates[0]->ID);
        $sorting = NpBlogPostDataReplacer::resolveBlogSorting($template_html);
    }

    NpBlogPostDataReplacer::$_activeSorting = $sorting;
    $sorting_params = NpBlogPostDataReplacer::_prepareSortingQuery(array(), '', $sorting);
    if (isset($sorting_params['orderby'], $sorting_params['order'])) {
        $query->set('orderby', $sorting_params['orderby']);
        $query->set('order', $sorting_params['order']);
    }
}
add_action('pre_get_posts', 'sorting_posts');

function import_categories_in_posts($categories, $added_terms) {
    $category_old_new_ids = array();
    foreach ($categories as $post_category) {
        $old_id = isset($post_category['id']) ? $post_category['id'] : null;
        $parent_id = isset($post_category['categoryId']) ? $post_category['categoryId'] : null;
        $title = isset($post_category['title']) ? $post_category['title'] : null;

        if ($old_id && $title && !$parent_id) {
            $category_old_new_ids[$old_id] = wp_create_category($title);
        }
        if ($old_id && $title && $parent_id && isset($category_old_new_ids[$parent_id])) {
            $category_old_new_ids[$old_id] = wp_create_category($title, $category_old_new_ids[$parent_id]);
        }
        if (isset($category_old_new_ids[$old_id])) {
            $added_terms[] = array(
                'term_id' => (int)$category_old_new_ids[$old_id],
                'taxonomy' => 'category'
            );
        }
    }

    if ($category_old_new_ids) {
        update_option('post_category_old_new_ids', $category_old_new_ids);
    }

    return $added_terms;
}