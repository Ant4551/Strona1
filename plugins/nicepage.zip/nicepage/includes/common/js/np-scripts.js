jQuery(document).ready(function($) {
    //categories filter in np page
    $('.u-blog .u-select-categories, .u-products .u-select-categories')
        .on('change', function () {
            const productList = $(this).closest('.u-products');
            const isBlog = $(this).closest('.u-blog').length > 0;
            if (!isBlog && productList.attr('data-products-datasource') === 'site') {
                return;
            }
            const paramName = isBlog ? 'postsCategoryId' : 'categoryId';
            const selectedValue = $(this).val();

            const url = new URL(window.location.href);
            const params = new URLSearchParams(url.search);

            params.delete('paged');
            params.delete(paramName);
            if (selectedValue) {
                params.set(paramName, selectedValue);
            }

            url.search = params.toString();
            window.location.href = url.toString();
        });
});
