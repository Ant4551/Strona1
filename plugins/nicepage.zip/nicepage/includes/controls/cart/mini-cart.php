<?php
// phpcs:disable WordPress.Security.EscapeOutput
defined('ABSPATH') or die;

$post_id = get_the_ID();
$data_provider = np_data_provider($post_id);
$headerNp = $data_provider->getNpHeader();
$headerItem = json_decode($headerNp, true);
$publishHeader = $data_provider->getTranslation($headerItem, 'header');
if (preg_match('/<\!--shopping_cart-->([\s\S]+?)<\!--\/shopping_cart-->/', $publishHeader, $matches)) {
    $shoppingCartHtml = $matches[1];

    if (!isset(WC()->cart)) {
        return $shoppingCartHtml;
    }

    $shoppingCartHtml = preg_replace('/(\s+href=[\'"])([\s\S]+?)([\'"])/', '$1' . wc_get_cart_url() . '$3', $shoppingCartHtml);
    $shoppingCartHtml = preg_replace('/<!--np_json-->([\s\S]+?)<\!--\/np_json-->/', '', $shoppingCartHtml);
    $shoppingCartHtml = preg_replace_callback(
        '/<\!--shopping_cart_count-->([\s\S]+?)<\!--\/shopping_cart_count-->/',
        function () {
            $count = WC()->cart->get_cart_contents_count();
            return isset($count) ? $count : 0;
        },
        $shoppingCartHtml
    );
    if (preg_match('/<a[\s\S]+?class=[\'"]([\s\S]+?)[\'"]/', $shoppingCartHtml, $matches)) {
        $shoppingCartHtml = str_replace($matches[1], '', $shoppingCartHtml);
    }
    // WooCommerce adds the widget_shopping_cart_content wrapper in AJAX fragments.
    // Return only cart markup here to avoid nested wrappers after add-to-cart.
    echo $shoppingCartHtml;
}
// phpcs:enable