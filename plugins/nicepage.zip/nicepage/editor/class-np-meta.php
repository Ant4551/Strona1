<?php
defined('ABSPATH') or die;

class NpMeta {

    public static $baseTableName = 'nicepage_meta';
    public static $_cache = array();

    /**
     * Initialize method
     */
    public static function init() {
        global $wpdb;
        $wpdb->nicepage_meta = $wpdb->prefix . self::$baseTableName;
        include_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $tableCache = wp_cache_get('np_meta_table');
        if (!$tableCache) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $np_meta_table = $wpdb->get_var("SHOW TABLES LIKE '$wpdb->nicepage_meta'");
            wp_cache_set('np_meta_table', $np_meta_table);
            $tableCache = $np_meta_table;
        }
        if ($tableCache !== $wpdb->nicepage_meta) {
            // first load = add table to database
            self::updateTable();
        }
    }

    /**
     * Get nicepage_meta value
     *
     * @param string $meta_key
     *
     * @return string|false
     */
    public static function get($meta_key) {
        global $wpdb;
        $wpCache = wp_cache_get('all_np_meta');
        if (!$wpCache) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $all_np_meta = $wpdb->get_results("SELECT * FROM $wpdb->nicepage_meta");
            wp_cache_set('all_np_meta', $all_np_meta);
            $wpCache = $all_np_meta;
        }
        if (!isset(self::$_cache[$meta_key])) {
            self::$_cache[$meta_key] = '';
            $keys = array_map(
                function ($e) {
                    return is_object($e) ? $e->meta_key : $e['meta_key'];
                }, $wpCache
            );
            $keyIndex = array_search($meta_key, $keys);
            if ($keyIndex !== false) {
                if (isset($wpCache[$keyIndex]->meta_value)) {
                    self::$_cache[$meta_key] = $wpCache[$keyIndex]->meta_value;
                }
            }
        }
        return self::$_cache[$meta_key];
    }

    /**
     * Update nicepage_meta value
     *
     * @param string $meta_key
     * @param string $meta_value
     *
     * @return bool
     */
    public static function update($meta_key, $meta_value) {
        global $wpdb;

        $result = self::_updateRow($meta_key, $meta_value);
        if ($result === false && self::_reconnectWithBiggerPacket()) {
            $result = self::_updateRow($meta_key, $meta_value);
        }
        if ($result === false) {
            self::_logUpdateError('update', $meta_key, $meta_value);
            return false;
        }
        if ($result === 0) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $existing = $wpdb->get_var(
                $wpdb->prepare("SELECT 1 FROM $wpdb->nicepage_meta WHERE meta_key=%s LIMIT 1", $meta_key)
            );
            if (!empty($wpdb->last_error)) {
                self::_logUpdateError('select', $meta_key, $meta_value);
                return false;
            }
            if ($existing === null) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $result = $wpdb->insert(
                    $wpdb->nicepage_meta,
                    array(
                        'meta_key' => $meta_key,
                        'meta_value' => $meta_value,
                    )
                );
                if ($result === false) {
                    self::_logUpdateError('insert', $meta_key, $meta_value);
                    return false;
                }
            }
        }
        self::$_cache[$meta_key] = $meta_value;
        wp_cache_delete('all_np_meta');
        return true;
    }

    /**
     * Write the value to the existing nicepage_meta row
     *
     * @param string $meta_key
     * @param string $meta_value
     *
     * @return int|false Number of updated rows or false on error
     */
    private static function _updateRow($meta_key, $meta_value) {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return $wpdb->update(
            $wpdb->nicepage_meta,
            array('meta_value' => $meta_value),
            array('meta_key' => $meta_key)
        );
    }

    /**
     * Prepare a repeat of the write rejected by MySQL as bigger than max_allowed_packet
     *
     * MySQL reports such a query either by the variable name or by closing the connection.
     * A connection keeps the max_allowed_packet it was opened with, so the raised global limit
     * (the same one the plugin sets on activation) applies only to a new connection.
     *
     * @return bool
     */
    private static function _reconnectWithBiggerPacket() {
        global $wpdb;

        if (!preg_match('/max_allowed_packet|server has gone away|Lost connection/i', $wpdb->last_error)) {
            return false;
        }
        $packet_size = 32 * 1024 * 1024;
        // @codingStandardsIgnoreStart
        if ((int) $wpdb->get_var('SELECT @@global.max_allowed_packet') < $packet_size) {
            // Without permission to change the global variable, retrying the write will not help.
            if ($wpdb->query('SET @@global.max_allowed_packet = ' . $packet_size) === false) {
                return false;
            }
        }
        // @codingStandardsIgnoreEnd
        $wpdb->close();
        return $wpdb->check_connection(false);
    }

    /**
     * Log nicepage_meta update error
     *
     * @param string $operation
     * @param string $meta_key
     * @param string $meta_value
     */
    private static function _logUpdateError($operation, $meta_key, $meta_value) {
        global $wpdb;

        $message = sprintf(
            'Nicepage metadata write failed: operation=%s; meta_key=%s; data_size=%d; last_error=%s',
            str_replace(array("\r", "\n"), ' ', $operation),
            str_replace(array("\r", "\n"), ' ', $meta_key),
            strlen($meta_value),
            str_replace(array("\r", "\n"), ' ', $wpdb->last_error)
        );
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
        error_log($message);
    }

    /**
     * Create nicepage_meta table if it not exists
     */
    public static function updateTable() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $wpdb->nicepage_meta (
          id mediumint(9) NOT NULL AUTO_INCREMENT,
          meta_key varchar(255) NOT NULL,
          meta_value longtext DEFAULT '' NOT NULL,
          PRIMARY KEY  (id)
        ) $charset_collate;";

        dbDelta($sql);
    }
}
NpMeta::init();