<?php defined('ABSPATH') or die;
// phpcs:disable WordPress.Security.EscapeOutput
$domain = NpEditor::getDomain();

$loader_path = $domain
    ? $domain . '/Editor/loader.js'
    : APP_PLUGIN_URL . 'editor/assets/app/loader.js?ver=' . APP_PLUGIN_VERSION;

$sw_path = NpAction::getActionUrl('np_route_service_worker');

header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <?php
    // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
    echo '<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,700"/>';
    ?>
    <script>window.loadAppHook = parent.loadAppHook;</script>
    <script>if (!parent.dataBridge) {alert('The editor was launched incorrectly. Please contact the Support.'); parent.location.reload();}</script>
    <script id="loader-script" type="text/javascript"
            src="<?php echo $loader_path; ?>"
            data-swurl="<?php echo $sw_path; ?>"
            data-assets="<?php echo APP_PLUGIN_URL; ?>editor/assets/app/"
            data-processor="wp">
    </script>
</head>
<body>

</body>
</html>
<?php // phpcs:enable ?>